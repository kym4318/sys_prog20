#include<stdio.h>

int main(){
	int num = 0x01234567;
	unsigned int num2 = -1;

	int bit =0;
	while(num2)
	{
		bit+=(num2&1);
		num2= num2 >> 1;
	}

	printf("%d bit\n" , bit);
	//printf("%x\n",*((char*)&num));	
	if(*((char*)&num) == 0x67){
		printf("little endian\n");
	}
	else{
		printf("big endian\n");
	}
	
	return 0;
}
